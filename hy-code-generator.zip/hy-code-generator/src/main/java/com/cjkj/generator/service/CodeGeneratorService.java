package com.cjkj.generator.service;

import com.baomidou.mybatisplus.extension.service.IService;
import com.cjkj.common.model.PageData;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Map;

/**
 * @author RenPL
 * @Description:
 * @date 2019/11/30 15:03
 */
@Service
public interface CodeGeneratorService extends IService {

    /**
     * 分页查询表结构信息列表
     *
     * @param map
     * @return
     */
    PageData queryList(Map<String, Object> map);

    /**
     * 根据表名查询表结构信息
     *
     * @param tableName
     * @return
     */
    Map<String, String> queryTable(String tableName);

    /**
     * 根据表名查询表的所有字段信息
     *
     * @param tableName
     * @return
     */
    List<Map<String, String>> queryColumns(String tableName);

    /**
     * 根据表名生成代码
     *
     * @param tableNames
     * @return
     */
    byte[] generatorCode(String[] tableNames);
}

